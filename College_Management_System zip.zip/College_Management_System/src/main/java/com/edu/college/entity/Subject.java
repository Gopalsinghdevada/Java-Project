package com.edu.college.entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

@Entity
public class Subject {

	@Id
	 @GeneratedValue(strategy = GenerationType.IDENTITY)
	 private Integer subjectId;
	 
	 @NotEmpty
	 @Size(min=3, max=30, message="Subject Should not be Empty")
	 private String subjectName;
	 

	//relation with student
	  @ManyToMany
	  @JoinTable(name = "Student_Subject",joinColumns = @JoinColumn(name ="subject_id" ),
	  
			     inverseJoinColumns = @JoinColumn(name = "student_id"))
	   
	  Set<Student>Student_Subject = new HashSet<>();
	  
	  
	    //relation with teacher
	    @ManyToOne(cascade = CascadeType.ALL)
		
		@JoinColumn(name="teacher_id", referencedColumnName = "teacherId")
	    
		private Teacher teacher;
	    
	    
	public Set<Student> getStudent_Subject() {
		return Student_Subject;
	}

   public void setStudent_Subject(Set<Student> student_Subject) {
		Student_Subject = student_Subject;
	}

	public Teacher getTeacher() {
		return teacher;
	}

	public void setTeacher(Teacher teacher) {
		this.teacher = teacher;
   }

	public Integer getSubjectId() {
		return subjectId;
	}

	public void setSubjectId(Integer subjectId) {
		this.subjectId = subjectId;
	}

	public String getSubjectName() {
		return subjectName;
	}

	public void setSubjectName(String subjectName) {
		this.subjectName = subjectName;
	}

	
	
	public void assignStudent(Student student) {
		Student_Subject.add(student);
	}

	public void assignTeacher(Teacher teacher2) {
		this.teacher=teacher2;
		
	}	
	
	
}
