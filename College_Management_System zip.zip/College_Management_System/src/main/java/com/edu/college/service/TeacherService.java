package com.edu.college.service;

import java.util.List;

import com.edu.college.entity.Teacher;
import com.edu.college.error.TeacherNotFoundException;

public interface TeacherService {

	Teacher addTeacher(Teacher teacher);

	List<Teacher> getAllTeacher();

	void deleteById(Integer tid) throws TeacherNotFoundException;

	Teacher updateTeacher(Integer tid, Teacher teacher) throws TeacherNotFoundException;

	Teacher findById(Integer tid) throws TeacherNotFoundException;

	Teacher findByTeacherName(String teacherName) throws TeacherNotFoundException;
}
