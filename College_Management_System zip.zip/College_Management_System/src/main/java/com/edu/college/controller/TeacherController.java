package com.edu.college.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.edu.college.entity.Teacher;
import com.edu.college.error.TeacherNotFoundException;
import com.edu.college.repository.TeacherRepository;
import com.edu.college.service.TeacherService;

@RestController
public class TeacherController {

	 @Autowired
	 private TeacherService teacherService;
	@Autowired
	private TeacherRepository teacherRepository;
	 
	 @PostMapping("/teacher")
	 public ResponseEntity<Teacher> addTeacher(@Valid @RequestBody Teacher teacher) {
		 
		Teacher tea = teacherService.addTeacher(teacher);
		
		return new ResponseEntity<Teacher>(tea, HttpStatus.CREATED);
	 }
	 
	 
	 @GetMapping("/teacher")
	 public List<Teacher> getAllTeacher() {
		 
		 return teacherService.getAllTeacher();	 
	 }
	 
	 
	 @DeleteMapping("/teacher/{tid}")
	 public String deleteById(@PathVariable("tid") Integer tid) throws TeacherNotFoundException {
		 
		 teacherService.deleteById(tid);
		 
		 return "Record Deleted Sucessfully";	 
	 }
	 
	 
	 @PutMapping("/teacher/{tid}")
	 public Teacher updateTeacher(@PathVariable("tid")Integer tid, @RequestBody Teacher teacher) throws TeacherNotFoundException {
		 
		 return teacherService.updateTeacher(tid,teacher); 
	 }
	 @GetMapping("/teacher/{tid}")
	 public Teacher findById(@PathVariable("tid")Integer tid) throws TeacherNotFoundException {
		 
		return teacherService.findById(tid);	 
	 }
	 
	
	 @GetMapping("/teachername/{name}")
	 public Teacher findByTeacherName(@PathVariable("name")String teacherName) throws TeacherNotFoundException {
		 
		 return teacherService.findByTeacherName(teacherName);
	 }
	 @GetMapping("/teachertotalsalary")
	 public String teachertotalsalary() {
		float salary= teacherRepository.totalsalary();
		return "Total salary "+salary;
	 }
	 
}
