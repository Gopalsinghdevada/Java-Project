package com.edu.college.service;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.edu.college.entity.Student;
import com.edu.college.error.StudentNotFoundException;

public interface StudentService {

	Student addStudent(Student student);

	List<Student> getAllStudent();

	void deleteById(Integer stuid) throws StudentNotFoundException;

	Student updateStudent(Integer stuid, Student student) throws StudentNotFoundException;

	Student findById(Integer stuid) throws StudentNotFoundException;

	Student findByStudentName(String studentName) throws StudentNotFoundException;

	}
