package com.edu.college.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;

import com.edu.college.repository.StudentRepository;
import com.edu.college.repository.TeacherRepository;

public class ProfitandLoss {

	@Autowired
	private StudentRepository studentRepository;
	
	@Autowired
	private TeacherRepository teacherRepository;
	
	
	@GetMapping("profitandloss")
	
	public String profitAndLoss() {
		
	 float pf = studentRepository.totalfees()-teacherRepository.totalsalary();
	 
	 if(pf>0)
			
		return " Profit "+pf;
		
	 else
			
		return " Loss ";
	 
	}
}
