package com.edu.college.error;

public class TeacherNotFoundException extends Exception{

	public TeacherNotFoundException(String message) {
		super(message);
	}
}
