package com.edu.college.repository;

import java.lang.annotation.Repeatable;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;

import com.edu.college.entity.Student;

@Repository
public interface StudentRepository extends JpaRepository<Student, Integer>{
	Student findByStudentName(String studentName);
@Query("select sum(m.studentFees) from Student m")
	float totalfees();
    
}
