package com.edu.college.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.edu.college.entity.Student;
import com.edu.college.error.StudentNotFoundException;
import com.edu.college.repository.StudentRepository;
import com.edu.college.repository.TeacherRepository;

@Service
public class StudentServiceimpl implements StudentService{

	@Autowired
	 private StudentRepository studentRepository;
    @Autowired
    private TeacherRepository teacherRepository;
	 
	@Override
	public Student addStudent(Student student) {
		
		return studentRepository.save(student) ;
	}


	@Override
	public List<Student> getAllStudent() {
		
		return studentRepository.findAll();
	}


	@Override
	public void deleteById(Integer stuid) throws StudentNotFoundException {
		
		Optional<Student> student = studentRepository.findById(stuid);
		
		   if(!student.isPresent()) {
			   
			  throw new StudentNotFoundException("Student Id not Found");	   
		   }
		   
		   else {
			   
			   studentRepository.deleteById(stuid);
		   }	
	    }


	@Override
	public Student updateStudent(Integer stuid, Student student) throws StudentNotFoundException {
		
		Optional<Student> student1 = studentRepository.findById(stuid);
		
		  if(!student1.isPresent()) {
			  
			  throw new StudentNotFoundException("Student Id not Found");
		  }
		  
		  else {
			  
			   Student s = studentRepository.findById(stuid).get();
			   
			     if(student.getStudentAddress()!=null)
			    	 
			    	 s.setStudentAddress(student.getStudentAddress());
			     
			     if(student.getStudentAge()!=0)
			    	 
			    	 s.setStudentAge(student.getStudentAge());
			     
			     if(student.getStudentEmailId()!=null)
			    	 
			    	 s.setStudentEmailId(student.getStudentEmailId());
			     
			     if(student.getStudentMobileNo()!=null)
			    	 
			    	 s.setStudentMobileNo(student.getStudentMobileNo());
			     
			     if(student.getStudentFees()!=0)
			    	 
			    	 s.setStudentFees(student.getStudentFees());
			     
			     if(student.getStudentName()!=null)
			    	 
			    	 s.setStudentName(student.getStudentName());
			     
			     return studentRepository.save(s);
		    }
}


	@Override
	public Student findById(Integer stuid) throws StudentNotFoundException {
		Optional<Student>student = studentRepository.findById(stuid);
		
		 if(!student.isPresent()) {
			   
			  throw new StudentNotFoundException("Student Id not Found");	   
		   }
		   
		   else {
			   
			  return studentRepository.findById(stuid).get();
		   }
	}


	@Override
	public Student findByStudentName(String studentName) throws StudentNotFoundException {
		Student student = studentRepository.findByStudentName(studentName);
		
		 if(student==null) {
			   
			  throw new StudentNotFoundException("Student Name not Found");	   
		   }
		   
		   else {
			   
			   return studentRepository.findByStudentName(studentName);
		   }
	    }
	}





	







	
