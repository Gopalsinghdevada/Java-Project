package com.edu.college.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.edu.college.entity.Student;
import com.edu.college.entity.Subject;
import com.edu.college.entity.Teacher;
import com.edu.college.error.StudentNotFoundException;
import com.edu.college.error.SubjectNotFoundException;
import com.edu.college.error.TeacherNotFoundException;
import com.edu.college.repository.StudentRepository;
import com.edu.college.repository.SubjectRepository;
import com.edu.college.repository.TeacherRepository;

@Service
public class SubjectServiceimpl implements SubjectService{

	@Autowired
	 private SubjectRepository subjectRepository;
    
	 @Autowired
	 private StudentRepository studentRepository;
	 
	 @Autowired
	 private TeacherRepository teacherRepository;
	 
	 
	@Override
	public Subject addSubject(Subject subject) {
	
		return subjectRepository.save(subject) ;
	}


	@Override
	public List<Subject> getAllSubject() {
		
		return subjectRepository.findAll();
	}


	@Override
	public void deleteById(Integer subid) throws SubjectNotFoundException {
		
		Optional<Subject> subject = subjectRepository.findById(subid);
		
		  if(!subject.isPresent()) {
			  
			  throw new SubjectNotFoundException("Subject Id not Found");
		  }
		  
		  else {
			  
			  subjectRepository.deleteById(subid);
		  }
	  }


	@Override
	public Subject updateSubject(Integer subid, Subject subject) throws SubjectNotFoundException {
		
		Optional<Subject> subject1 = subjectRepository.findById(subid);
		
		  if(!subject1.isPresent()) {
			  
			  throw new SubjectNotFoundException("Subject Id not Found");
		  }
		  
		  else {
			  
			  Subject s= subjectRepository.findById(subid).get();
			   
			    if(subject.getSubjectName()!=null)
			    	
			    	s.setSubjectName(subject.getSubjectName());
			        
			    return subjectRepository.save(s) ;
			}
		}


	@Override
	public Subject assignStudentToSubject(Integer subid, Integer stuid) throws SubjectNotFoundException, StudentNotFoundException {
		
Optional<Subject> subject = subjectRepository.findById(subid);
		
		Optional<Student> student = studentRepository.findById(stuid);
		   
		  if(!subject.isPresent()) {
			  
			  throw new SubjectNotFoundException("Subject Id not Found");
		  }
		  
		  else if(!student.isPresent()) {
			  
			  throw new StudentNotFoundException("Student Id not Found");	  
		  }
		  
		  else {
			  
			  Subject subject1 = subjectRepository.findById(subid).get();
			  
			  Student student1 = studentRepository.findById(stuid).get();
			  
		      subject1.assignStudent(student1);
		
		      return subjectRepository.save(subject1);
	      }
	}


	@Override
	public Subject assignTeacherToSubject(Integer subid, Integer tid) throws SubjectNotFoundException, TeacherNotFoundException {
		
Optional<Subject> subject = subjectRepository.findById(tid);
		
		Optional<Teacher> teacher = teacherRepository.findById(tid);
		  
	      if(!subject.isPresent()) {
			  
			  throw new SubjectNotFoundException("Subject Id not Found");
		  }
		  
		  else if(!teacher.isPresent()) {
			  
			  throw new TeacherNotFoundException("Teacher Id not Found");	  
		  }
		  
		  else {
			  
			  Subject subject2= subjectRepository.findById(subid).get();
			  
			  Teacher teacher1 = teacherRepository.findById(tid).get();
			  
		      subject2.assignTeacher(teacher1);
		
		      return subjectRepository.save(subject2);
	      }
	}


	@Override
	public Subject findById(Integer subid) throws SubjectNotFoundException {
		Optional<Subject> subject = subjectRepository.findById(subid);
		
		  if(!subject.isPresent()) {
			  
			  throw new SubjectNotFoundException("Subject Id not Found");
		  }
		  
		  else {	  
			  
			  return subjectRepository.findById(subid).get();
		  }
	}


	@Override
	public Subject findBySubjectName(String subjectName) throws SubjectNotFoundException {
		Subject subject = subjectRepository.findBySubjectName(subjectName);
		
		  if(subject==null) {
			  
			  throw new SubjectNotFoundException("Subject Name not Found");
		  }
		  
		  else {	  
			  
			  return subjectRepository.findBySubjectName(subjectName);
		  }
	  }
	}

