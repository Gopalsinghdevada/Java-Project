package com.edu.college.service;

import java.util.List;

import com.edu.college.entity.Subject;
import com.edu.college.error.StudentNotFoundException;
import com.edu.college.error.SubjectNotFoundException;
import com.edu.college.error.TeacherNotFoundException;

public interface SubjectService {

	Subject addSubject(Subject subject);

	List<Subject> getAllSubject();

	void deleteById(Integer subid) throws SubjectNotFoundException;

	Subject updateSubject(Integer subid, Subject subject) throws SubjectNotFoundException;

	Subject assignStudentToSubject(Integer subid, Integer stuid) throws SubjectNotFoundException, StudentNotFoundException;

	Subject assignTeacherToSubject(Integer subid, Integer tid) throws SubjectNotFoundException, TeacherNotFoundException;
	
	Subject findById(Integer subid) throws SubjectNotFoundException;

	Subject findBySubjectName(String subjectName) throws SubjectNotFoundException;

}
